/**
 * 
 */
package com.pavuluri;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.Writer;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.function.Predicate;

import com.google.common.base.Joiner;
import com.google.common.base.Optional;
import com.google.common.base.Preconditions;
import com.google.common.graph.EndpointPair;
import com.google.common.graph.GraphBuilder;
import com.google.common.graph.MutableGraph;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

public class GraphExample {

	public static List<String> readFileInList(String fileName) {

		List<String> lines = Collections.emptyList();
		List<String> lines1 = new ArrayList<>();
		try {
			lines = Files.readAllLines(Paths.get(fileName), StandardCharsets.UTF_8);

			Predicate<String> p = x -> x.contains("#");
			for (String line : lines) {
				if (!p.test(line)) {
					lines1.add(line);
				}
			}
		}

		catch (IOException e) {
			e.printStackTrace();
		}
		return lines1;
	}

	public static void main(String[] args) {
		List l = readFileInList("p2p-Gnutella08.txt");

		Iterator<String> itr = l.iterator();
		MutableGraph<Integer> originalGraph = GraphBuilder.directed().expectedNodeCount(6500).build();
		while (itr.hasNext()) {
			String str = itr.next();
			String[] splited = str.split("\\s+");

			Optional<Integer> value1 = Optional.fromNullable(Integer.parseInt(splited[0]));
			Optional<Integer> value2 = Optional.fromNullable(Integer.parseInt(splited[1]));

			originalGraph.putEdge(checkValue(value1), checkValue(value2));
		}

		SerializableGraph serializableGraph = new SerializableGraph();
		serializableGraph.setEdges(originalGraph.edges());
		serializableGraph.setNodes(originalGraph.nodes());

		System.out.println(serializableGraph.toString());
		File jsonFile = new File("Output.json");

		try (Writer writer = new FileWriter(jsonFile.getPath())) {
			Gson gson = new GsonBuilder().create();
			gson.toJson(serializableGraph, writer);
		} catch (IOException e) {
			e.printStackTrace();
		}

		System.out.println(jsonFile.getAbsolutePath() + " is created successfully.");

		Joiner joiner = Joiner.on("; ").skipNulls();

		System.out.println("Edges:-");
		for (EndpointPair<Integer> edge : originalGraph.edges()) {
			System.out.println(joiner.join(edge.nodeU(), edge.nodeV()));
		}

	}

	public static Integer checkValue(Optional<Integer> input) {
		Integer value = input.get();
		Preconditions.checkArgument(value >= 0, "Illegal Argument passed: Negative value %s.", value);
		return value;
	}

}
